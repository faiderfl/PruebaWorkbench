#import yaml
#import pyodbc
#import impala.dbapi
#import impala.util

#from Impala_Helper import Helper
#from logger import logger
#from data_pipeline import data_pipeline
#from s3ManagerMulti import s3ManagerMulti
import json
import sys
    

def loadConfig(conf_path):
    if conf_path is None or conf_path == '':
        raise('Archivo de Configuración no puede ser Nulo')

    with open(conf_path) as f_in:
        json_str = f_in.read()
        return json.loads(json_str)


def query(id):
    configPath = "cfg.json"
    cfg = loadConfig(configPath)

    paths = cfg['libraryPaths']
    for path in paths:
        sys.path.append(path)

    from Impala_Helper import Helper
    from logger import logger

    i = 0
    fetchSize = cfg.get("fetchSize", 10000)
    # genera un log para imprimir mensajes
    log = logger(pathlog=cfg["rutaLog"],  logName=cfg["logName"])
    dbh = Helper(cfg, logger=log)
    cursor, iterator = dbh.getIterator(
        cfg["queryExtractor"] + "where id=" + id )
    header = [column[0] for column in cursor.description]
    numCols = len(header)
    hd = [header[i] for i in range(numCols)]

    rangoCols = range(numCols)

    while True:
        records = iterator.fetchmany(fetchSize)
        if len(records) == 0:
            break
        items = []
        for rec in records:
            item = {}
            for j in rangoCols:
                if rec[j] != None:
                  item[hd[j]] = rec[j]
            items.append(item)
            i = i + 1
        
    return items

if __name__ == '__main__':
    args = sys.argv
    result = query(args[1])
    print  ([result[0]])

    '''
    from impala.dbapi import connect
    conn = connect(host='impala.bancolombia.corp', port=21050)
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM proceso_enmascarado.cun_ci_contadores LIMIT 100')
    print (cursor.description)  # prints the result set's schema
    results = cursor.fetchall()
    # query and convert to pandas data frame
    #cur = conn.cursor()
    #cur.execute(
    #    'SELECT * proceso_cap_analit_y_gob_de_inf.phb_recomendacion_eco_habitat_s limit 1000')
    #df = impala.util.as_pandas(cur)
    #df.head(5)\
    '''
