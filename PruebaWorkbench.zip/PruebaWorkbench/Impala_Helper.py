# -*- coding: utf-8 -*-
"""
Created on Thu Aug 30 07:40:03 2018

Módulo que permite hacer una conexión odbc a Impala con funciones
que ayudan a la calendarización de procesos.

@author: RLARIOS
"""

import pyodbc
import time
import pandas as pd
import io

class Helper():
    def __init__(self , cache , logger = None ):
        """Inicializa el conector a bases de Datos ODBC - Impala

        Argumentos:
        cache -- Diccionario con los parámetros de conexión, valores Obligatorios en el Diccionario:
            connStr = Cadena de conexión a la base de datos o configuración DSN
            db = Base de datos de Impala por defecto
            infoLeng = tamaño para mostrar queries , por defecto 25 (Opcional en diccionario)
            fetchSize = tamaño de la cantidad de filas a traer, por defecto 10K (Opcional en diccionario)
        database -- base de datos, por defecto si no se envía valor es "default"
        refresh -- tasa de refresco de conexión.  Por defecto son 5 minutos
        logger -- Objeto tipo logger para realizar el loggeo del servicio
        """
        self.cache = cache
        self.log = logger
        self.con = None
        self.cursor = None
        self.CONN = self.cache["connStr"]
        self.currentDB = self.cache["db"]
        self.refreshTime = self.cache.get("refresh" , 5*60 )
        self.verbose = self.cache.get("verbose" , False )
        self.lastCon = 0
        self.lengthMSG = self.cache.get("infoLeng", 50)

    def useDataBase(self , dbName ):
        """Genera un query a Impala para que use una base de datos específica por defecto."""
        try:
            self.currentDB = dbName
            cursor = self.getConn().cursor()
            cursor.execute("use " + self.currentDB)
            self.printI("Switched to DB: " + self.currentDB)
        except Exception as e:
            self.printE("Problemas con useDataBase!: " + str(e))
            raise

    def getConn(self  ):
        """Trae una conexión a la base de datos específica."""
        try:
            actual = int(round(time.time()))
            elapsed = (actual - self.lastCon)
            if self.lastCon == 0 or elapsed > self.refreshTime:
                #Entra aqui en el caso que sea una nueva conexión o la ultima conexión que se trae
                #fue hace mayor que el tiempo de refresh
                
                self.printI("Elapsed: {0}, Refresh = {1}".format(elapsed , self.refreshTime))
                self.printI("Refreshing Connection")
                self.close()
                self.con = pyodbc.connect(self.CONN, autocommit=True)
                self.cursor = self.con.cursor()
                self.lastCon = int(round(time.time()))
                self.cursor.execute("use " + self.currentDB)
                if self.verbose:
                    self.printI("Switched to DB: " + self.currentDB)
                return self.con
            else:
                return self.con
        except Exception as e:
            self.printE("Problemas con getConn!: " + str(e))
            raise



    def removeComment( self , text):
        """Remueve los posibles comentarios que el query enviado pudiera tener."""
        try:
            a = text.find("--")
            if a > -1:
                return text[:text.find("--")]
            else:
                return text
        except Exception as e:
            self.printE("Problemas con removeComment!: " + str(e))
            raise



    def getQueries(self , path , params = None):
        """Trae los queries sin comentarios de un archivo y devuelve una lista con cada uno"""
        try:
            qs = []
            tex = ''
            with io.open (path , encoding = 'UTF-8') as fi:
                for line in fi:
                    tex += self.removeComment(line)

            spli = tex.split(";")
            for el in spli:
                if el.strip() != '':
                    # Se convierten los parámetros
                    if params is not None:
                        el = el.format(**params)

                    qs.append( el.strip() )

            return qs
        except Exception as e:
            self.printE("Problemas con getQueries!: " + str(e))
            raise


    def executeFile(self ,  filePath , params = None ):
        """Ejecuta un archivo especificado en filePath"""
        i = 1
        try:
            tic = time.time()
            self.printI('Executing FILE: {0}'.format(filePath ))
            lenMsg = self.lengthMSG
            queries = self.getQueries( filePath , params )
            
            for q in queries:
                cursor = self.getConn().cursor()
                if self.verbose:
                    self.printI(' -> Executing query {0}: {1}...'.format(i,q[:lenMsg]).replace("\n" , " "))
                cursor.execute( q )
                i += 1
            toc = time.time()
            self.printI('File Duration (s): {0}'.format( int(toc-tic) ))
        except Exception as e:
            self.printE("Problemas con executeFile!, Query {0}, Error: {1} ".format( i , e))
            raise


    def toCSV(self , query ,  fileName , params = None , sepa = "," , encode = "utf-8"  ):
        """Ejecuta un query específico y lo guarda en una ruta especificada en fileName"""
        try:
            if self.verbose:
                self.printI('Creating CSV: {0}'.format( fileName ))

            df = self.getDataFrame(query , params)
            df.to_csv(fileName , sep = sepa , encoding = encode , index=False)
            self.printI('CSV File Created: {0}'.format( fileName ))
        except Exception as e:
            self.printE("Problemas con toCSV!: " + str(e))
            raise

    def fromCSV(self , fileName , tablename , header = True , sep = "," , encod = "UTF-8" , dataTypes = None):
        """carga un archivo csv a una tabla de impala, intenta deducir cual es es el
        fromato de los datos y crea una tabla de acuerdo a estos valores
        No usar para tablas de más de 1000 registros"""
        try:
            if self.verbose:
                self.printI('readCSV: {0}'.format( fileName ))
            df = pd.read_csv(fileName , sep = sep , encoding = encod)
            self.fromPandasDF(df , tablename , fromCSV = True)    
            self.printI("Se ha cargado el archivo CSV satisfactoriamente")
            #return ins_stat

        except Exception as e:
            self.printE("Problemas con fromCSV!: " + str(e))
            raise

    def fromPandasDF(self , df , tablename , fromCSV = False , dataTypes = None ):
            """carga un archivo DF de pandas a una tabla de impala, intenta deducir cual 
            es es el fromato de los datos y crea una tabla de acuerdo a estos valores
            No usar para tablas de más de 1000 registros"""
            
            def getType(col ):
                if str(col)[:3] == "int":
                    if str(col) == "int32":
                        return "int"
                    else:
                        return "bigint"
                if str(col)[:5] == "float":
                    return "double"
                if str(col)[:4] == "bool":
                    return "boolean"
                else:
                    return "string"

            def createImpala(df , table):
                col_head = []
                cr = "create table {0} ( \n".format(table)
                cols = df.columns
                for j in range(len(cols)):
                    t = ""
                    if dataTypes is not None:
                        t = dataTypes[j]
                    else:
                        t = getType(df[cols[j]].dtype)
                    col_head.append(t)
                    if j == 0:
                        cr = cr + "\t  " + cols[j] + " " + t + " \n"
                    else:
                        cr = cr + "\t, " + cols[j] + " " + t + " \n"
                    j += 1

                cr = cr + ") stored as parquet "
                return cr , col_head

            def applyx(cell , types , isNull):
                if isNull :
                    if types.lower()[:7] == "varchar" or types.lower()[:4] == "char":
                        return "cast('null' as {0})".format(types)
                    else:
                        return "null"
                elif types.lower() == "string":
                    return "'" + str(cell).replace("'","\\'") + "'"
                elif types.lower()[:7] == "varchar" or types.lower()[:4] == "char" :
                    value = "'" + str(cell).replace("'","\\'") + "'"
                    return "cast({0} as {1})".format(value , types)
                else:
                    return str(cell)
            try:
                self.execute( "drop table if exists {0} purge".format(tablename) )
                create , head = createImpala( df , tablename )
                self.execute( create )

                ins_stat = "INSERT INTO TABLE "  + tablename + " VALUES \n"
                m = 0
                matrizNulos = df.isna().values
                for index, row in df.iterrows():
                    i = 0
                    rowST = []
                    for cell in row:
                        rowST.append(applyx(cell , head[i] , matrizNulos[m][i]))
                        i += 1
                    ins_stat = ins_stat + "(" + ",".join(rowST) + ") , \n"
                    m = m + 1
                
                #print(ins_stat[:-3])
                self.execute( ins_stat[:-3] )
                #print(ins_stat[:-3])
                self.execute( "compute stats " + tablename )
                if fromCSV == False:
                    self.printI("Se ha cargado el DF pandas satisfactoriamente")
                #return ins_stat

            except Exception as e:
                self.printE("Problemas con fromPandasDF!: " + str(e))
                raise



    def getIterator(self , query , params = None):
        """Ejecuta un query en específico.  Devuelve un Iterador a los resultados.  Usar este cuando queremos hacer un loop con fetchMany."""
        try:
            q = query
            if params is not None:
                q = q.format(**params)

            cursor = self.getConn().cursor()
            return cursor , cursor.execute( q )
        except Exception as e:
            self.printE("Problemas con getIterator!: " + str(e))
            raise

    def getRows(self , query ,  params = None  ):
        """Ejecuta un query en específico.  Una lista con los resultados.  Usar este cuando se quieren traer pocas filas"""
        try:
            lenMsg = self.lengthMSG
            if self.verbose:
                self.printI('Returning Rows for Query: {0} ...'.format(query[:lenMsg].replace("\n"," ")))

            cursor , iterator = self.getIterator( query , params )
            header = ",".join([column[0] for column in cursor.description])
            if self.verbose:
                self.printI('Header: {0}'.format(header) )
            res = []
            i = 0;
            while True:
                records = iterator.fetchmany( self.cache.get("fetchSize" , 10000 ) )
                i = i + len(records)
                if len(records) == 0:
                    break;
                res = res + records

            if self.verbose:
                self.printI('Returning {0} rows'.format( i ))
            return header , res
        except Exception as e:
            self.printE("Problemas con getRows!: " + str(e))
            raise



    def execute(self , query , params = None):
        """Ejecuta un query en específico.  especifico para lanzar consultas sin devolución de resultados"""
        try:
            lenMsg = self.lengthMSG
            if self.verbose:
                self.printI('Exec for Query: {0} ...'.format(query[:lenMsg].replace("\n"," ")))

            cursor , iterator = self.getIterator( query , params )
        except Exception as e:
            self.printE("Problemas con execute!: " + str(e))
            raise


    def getDataFrame(self , query ,  params = None  ):
        """Ejecuta un query en específico.  Devuelve un DataFrame de Pandas con los resultados.  Usar este cuando se quieren traer pocas filas"""
        try:
            lenMsg = self.lengthMSG
            if self.verbose:
                self.printI('Generando DF para Consulta: {0} ...'.format(query[:lenMsg].replace("\n"," ")))
            header , res = self.getRows( query , params )
            cols = header.split(",")
            dfRet = pd.DataFrame.from_records(res, columns=cols)

            return dfRet
        except Exception as e:
            self.printE("Problemas con getDataFrame!: " + str(e))
            raise

    def oneHot(self , table , colsOHE , drop = False):
        """Funcion para generar OneHotEncodings para una lista de columnas"""
        try:
            def getDistinct(column , table):
                q = "select distinct trim(cast({0} as string)) from {1} order by trim(cast({0} as string))".format(column , table)
                head , res = self.getRows( q  )
                return [x[0] for x in res]

            def getColumns(drop , colsOHE , table) :
                if drop:
                    q = "describe {0}".format(table)
                    head , res = self.getRows( q  )
                    fields = []
                    for row in res:
                        if row[0] not in colsOHE:
                            fields.append(row[0])

                    return ",".join(fields)
                else:
                    return "*"

            colsOHE = [x.lower() for x in colsOHE]
            self.printI('Creación de OneHotEncodings para columnas {0}, en tabla {1}'.format(colsOHE,table))

            q = """create table {0}_ohe stored as parquet as \nSelect {1} , \n """.format(table , getColumns(drop , colsOHE , table))
            mappings = {}
            for i in range(len(colsOHE)):
                values =   getDistinct(colsOHE[i] , table)
                cases = []
                for val in range(len(values)):
                    col_name = "{0}_{1}".format(colsOHE[i], val )
                    cases.append(" case when trim(cast({0} as string)) = '{1}' then 1 else 0 end as {2} \n".format(colsOHE[i],values[val],col_name))
                    mappings[col_name] = values[val]
                q = q + ",".join(cases) + ","

            q = q[:len(q)-1] + "FROM {0} ".format( table )

            self.execute("drop table if exists {0}_ohe purge".format(table))
            self.execute( q )
            self.execute("compute stats {0}_ohe ".format(table))
            if self.verbose:
                self.printI("Se crean los siguientes mapeos de columnas:")
                self.printI("COLUMNA -> VALOR \n ************ ")
            
            if self.verbose:
                for idx in mappings:
                    self.printI("{0} -> {1}".format(idx,mappings[idx]))
            
            self.printI('Creación de tabla {0}_ohe satisfactoria'.format( table ))
            return mappings

        except Exception as e:
            self.printE("Problemas con OneHotEncoding!: " + str(e))
            raise



    def transpose(self , table , cols_group , cols_trans , cols_sum):
        """FUNCION ALPHA: USAR BAJO TU PROPIO RIESGO!"""
        try:
            def getDistinct(column , table):
                q = "select distinct {0} from {1} order by {0}".format(column , table)
                head , res = self.getRows( q  )
                return [x[0] for x in res]

            def getTypes(cols_trans , table):
                q = "describe {0} ".format(table)
                head , res = self.getRows( q  )
                cols = [(x[0] , x[1]) for x in res] #(columna , tipo)
                tipos = {}
                for tup in cols:
                    if tup[0] in cols_trans:
                        tipos[tup[0]] = tup[1]

                return tipos

            def returnValue(colum , tipos , val):
                retVal = tipos[colum]
                if retVal in ["string","varchar","char"]:
                    return "'" + val + "'"
                else:
                    return val

            def columnName(value , column):
                x = str(column).lower()
                chars = [("á" ,"a") , ("é" ,"e") , ("í" ,"i") , ("ó" ,"o") , ("ú" ,"u") , ("ñ" ,"n") , (" " ,"_") , ("/" ,"_")]
                for tup in chars:
                    x = x.replace(tup[0] , tup[1])

                return str(value) + "_" + str(x)
            
            if self.verbose:
                self.printI('Creación de tabla a partir de {0}, con columnas de agrupación {1}, y columnas a transponer {2}'.format(table,cols_group,cols_trans))

            q = """create table {0}_trans stored as parquet as \nSelect {1} , \n """.format(table , ",".join(cols_group))
            tipos = getTypes(cols_trans , table)
            for col in range(len(cols_trans)):
                columna = cols_trans[col]
                dist_vals = getDistinct(columna , table)
                cases = []
                for val in dist_vals:
                    cases.append( "\tsum( case when {0} = {1} then {2} end) as {3} \n".format(columna, returnValue(columna,tipos,val) ,cols_sum[col],columnName(cols_sum[col],val)) )
                q = q + ",".join(cases) + ","

            q = q[:len(q)-1] + "FROM {0} \nGROUP BY {1}".format( table , ",".join(cols_group))

            self.execute("drop table if exists {0}_trans purge".format(table))
            self.execute( q )
            self.execute("compute stats {0}_trans ".format(table))
            self.printI('Tabla {0}_trans creada con éxito!'.format(table))


        except Exception as e:
            self.printE("Problemas con transpose!: " + str(e))
            raise

    def recreate(self , table):
        """Recrea una tabla como parquet en caso de ser necesario"""
        try:
            self.printI('Re-Creación de tabla a partir de {0}'.format(table))
            tableX = ""
            if table.find(".") != -1:
                tableX =  table[table.find(".")+1:]
            else:
                tableX = table
            self.execute("drop table if exists proceso.{0} purge".format(tableX))
            self.execute("create table proceso.{0} stored as parquet as select * from {0}".format(tableX))
            self.execute("drop table if exists {0} purge".format(table))
            self.execute("create table {0} stored as parquet as select * from proceso.{1} ".format( table , tableX))
            self.execute("compute stats {0} ".format( table ))

        except Exception as e:
            self.printE("Problemas con recreate!: " + str(e))
            raise




    def close(self):
        """cierra la conexión, en el caso que ya se haya conectado al menos una vez"""
        if self.lastCon != 0 and self.con is not None:
            self.printI('Closing Connection')
            self.con.close()


    def printI(self , msg ):
        if self.log is None:
            print(msg)
        else:
            self.log.Info(msg)

    def printE(self , msg ):
        if self.log is None:
            print(msg)
        else:
            self.log.Error(msg)
